import colors from 'tailwindcss/colors'
console.log(colors.red[500])
/** @type {import('tailwindcss').Config} */
export default {
    content: [
        "./index.html",
        "./src/**/*.{js,ts,jsx,tsx}"
    ],
    theme: {
        extend: {
            animation: {
                "fade-in": "fadeIn 0.4s ease-in-out",
            },
            keyframes: {
                fadeIn: {
                    "0%": { opacity: "0" },
                    "100%": { opacity: "1" },
                },
            },
            safelist: [
                {
                    pattern: /text-(red|green|blue|gray|white|black|yellow|pink|purple|indigo|orange|amber|lime|emerald|teal|cyan|sky|violet|fuchsia|rose)-(50|100|200|300|400|500|600|700|800|900)/,
                },
                {
                    pattern: /text-(xs|sm|base|lg|xl|2xl|3xl|4xl|5xl|6xl)/,
                },
            ],
            borderRadius: {
                lg: "var(--radius)",
            },
            // colors: {
            //     ...colors,
            //     primary: "#3B82F6",
            //     secondary: "#FBBF24",
            //     accent: "#F472B6",
            //     background: "#F9FAFB",
            //     foreground: "#111827",
            //     muted: "#6B7280",
            //     "muted-foreground": "#374151",
            //     "destructive": "#EF4444",
            //     "destructive-foreground": "#FFFFFF",
            // },
        },
    },
    plugins: [
        require("tailwindcss-animate")
    ],
}
